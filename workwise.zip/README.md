# FixxDigital_WorkWise
Workwise Front-End


# Changes
## 11 Apr 2017

Fix styling bug on landing page
- Line 359 and 390 to 393 of "assets/css/app/app-landing.css"
